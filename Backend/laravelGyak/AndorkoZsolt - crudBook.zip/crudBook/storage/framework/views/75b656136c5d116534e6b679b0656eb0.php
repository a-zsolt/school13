<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('books.index')); ?>">Könyvek</a>
        <a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Új könyv</a>
    </div>
</nav>
<?php /**PATH /Users/zsoltandorko/Documents/school13/Backend/laravelGyak/crudBook/resources/views/components/nav.blade.php ENDPATH**/ ?>