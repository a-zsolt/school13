<?php $__env->startSection('content'); ?>
    <table class="table table-hover">
        <thead>
            <tr>
                <th scope="col">Cím</th>
                <th scope="col">Szerző</th>
                <th scope="col">Év</th>
                <th scope="col">Ár</th>
                <th scope="col">Műveletek</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th scope="row"><?php echo e($book->title); ?></th>
                    <td><?php echo e($book->author); ?></td>
                    <td><?php echo e($book->published_year); ?></td>
                    <td><?php echo e($book->price); ?> Ft</td>
                    <td>
                        <div class="d-inline-flex gap-2">
                            <a href="<?php echo e(route('books.edit', ['id' => $book->id])); ?>" class="btn btn-outline-info">Szerkesztés</a>
                            <form method="POST" action="<?php echo e(route('books.destroy', ['id' => $book->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-outline-danger">X</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert alert-info" role="alert">
                    Nincsen megjeleníthető könyv!
                </div>
            <?php endif; ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/zsoltandorko/Documents/school13/Backend/laravelGyak/crudBook/resources/views/books/index.blade.php ENDPATH**/ ?>