<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <a class="navbar-brand" href="{{ route('books.index') }}">Könyvek</a>
        <a href="{{ route('books.create') }}" class="btn btn-primary">Új könyv</a>
    </div>
</nav>
